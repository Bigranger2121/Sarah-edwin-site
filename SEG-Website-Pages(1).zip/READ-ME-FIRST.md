# SEG website pages — brass accent

Everything here uses your live site design system. The CSS, header, and footer are
extracted from `index.html` at build time, so the sub-pages inherit Fraunces, Manrope,
the cream/ink palette, `.btn`, `.eyebrow`, `.shell`, and the reveal animations. There is
no second design system.

## Accent

The accent is now brass. Only the token VALUES changed — the variable names stay
`--clay` / `--clay-deep` so every existing rule keeps working untouched:

    --clay:       #b98a44;   (was #b07355)
    --clay-deep:  #8f6a32;   (was #8f5a40)
    --clay-soft:  rgba(185, 138, 68, 0.12);

All hard-coded `rgba(176,115,85,...)` uses were updated to `rgba(185,138,68,...)`.
To change the accent again, edit those three values in `index.html` and re-run the build.

## Files

    index.html                                    your homepage, updated
    how-we-work/index.html
    resources/index.html
    resources/tsa-exit-business-case/index.html
    resources/cloud-migration-savings/index.html
    day-1-readiness/index.html                    gated chapter request
    day-1-readiness/thanks/index.html             post-submit
    _redirects
    WORKER-PATCH.md                               add the `excerpt` form_type branch

Copy everything except the two .md files into your project root, next to your
existing index.html (which this replaces).

## What changed on the homepage

- Nav: How We Work + Resources in header, mobile menu, and footer
- Header nav spacing moved from `gap` to `li + li { margin-left }` — flex gap has
  patchy support on older engines, margins do not
- "Home" removed from the DESKTOP header only (the brand lockup already links to #top);
  nine items would have crowded. Mobile menu keeps it.
- Approach section: closing block + "See the full methodology" button
- New Resources section after Approach, three cards
- Service cards: "How we deliver this work" links
- Hero: second CTA now points to /how-we-work/; `Est. —` placeholder replaced
- Transition Advisory + Managed Modernization prose now match their bullet lists
- `form_type="contact"` added to the contact form (it was missing; network form had it)
- JSON-LD: service descriptions corrected, SiteNavigationElement added

## Sub-page notes

The sub-page header locks to its solid cream state (`.site-header.is-solid`) because
those pages open against a dark masthead rather than a photographic hero. The active
nav item is marked with `aria-current="page"` and shows the brass underline.

## Rebuilding

If you edit `index.html`, re-run `build_site_pages.py` so the sub-pages pick up the
change. They read the CSS, header, and footer straight out of it.
