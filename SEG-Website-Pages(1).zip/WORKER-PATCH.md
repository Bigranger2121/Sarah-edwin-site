# Worker patch — add the `excerpt` form type

Your Worker already routes on a `form_type` field (`contact` and `network`). The excerpt form uses the same pattern, so this is one more branch — **not a new route or a new Worker**.

The form posts to `https://sarah-edwin-form.micheal-marable.workers.dev` with:

```json
{
  "form_type": "excerpt",
  "name":      "...",
  "email":     "...",
  "company":   "...",
  "situation": "...",
  "website":   ""
}
```

---

## 1. Add the branch

Wherever you switch on `form_type`, add a third case:

```js
if (data.form_type === 'excerpt') {
  return handleExcerpt(data, env);
}
```

## 2. Add the handler

```js
async function handleExcerpt(data, env) {
  const name      = (data.name || '').trim();
  const email     = (data.email || '').trim();
  const company   = (data.company || '').trim();
  const situation = (data.situation || '').trim();

  if (!name || !email.includes('@')) {
    return json({ ok: false, error: 'Name and a valid work email are required.' }, 400);
  }

  const first = esc(name.split(' ')[0]);

  // 1 — deliver the chapter
  const deliver = sendEmail(env, {
    to: [email],
    reply_to: env.NOTIFY_TO,
    subject: 'Day 1 Readiness — chapter from our practitioner training material',
    html: `
<div style="font-family:Helvetica,Arial,sans-serif;color:#1f232c;line-height:1.65;max-width:560px">
  <p>${first},</p>
  <p>Here is the Day 1 Readiness chapter, as requested.</p>
  <p style="margin:26px 0">
    <a href="${env.EXCERPT_URL}"
       style="background:#14171f;color:#f6f1e7;padding:14px 28px;text-decoration:none;
              font-size:14px;font-weight:600;display:inline-block;border-radius:999px">
      Download the chapter
    </a>
  </p>
  <p>It covers the three tests that keep Day 1 scope from growing, rehearsal discipline,
  measuring readiness as a number rather than a colour, and the go/no-go decision.</p>
  <p>If you are working through a transaction and want to talk about how any of it applies
  to your situation, just reply to this email.</p>
  <p style="margin-top:28px">Mike Marable<br>
  <span style="color:#6b6e75">The Sarah Edwin Group — Built for what's next.</span></p>
  <hr style="border:0;border-top:1px solid #e2ddd2;margin:26px 0">
  <p style="font-size:12px;color:#6b6e75">
    The Sarah Edwin Group · 1700 Northside Drive NW, Suite A7 PMB 1289, Atlanta, GA 30318<br>
    You received this because you requested it at sarahedwingroup.com.
  </p>
</div>`
  });

  // 2 — notify internally
  const notify = sendEmail(env, {
    to: [env.NOTIFY_TO],
    reply_to: email,
    subject: `Chapter request — ${name}${company ? ' · ' + company : ''}`,
    html: `
<div style="font-family:Helvetica,Arial,sans-serif;line-height:1.7">
  <p><b>Day 1 Readiness chapter requested</b></p>
  <table cellpadding="6" style="font-size:14px;border-collapse:collapse">
    <tr><td style="color:#6b6e75">Name</td><td>${esc(name)}</td></tr>
    <tr><td style="color:#6b6e75">Email</td><td>${esc(email)}</td></tr>
    <tr><td style="color:#6b6e75">Company</td><td>${esc(company) || '—'}</td></tr>
    <tr><td style="color:#6b6e75">Situation</td><td>${esc(situation) || '—'}</td></tr>
  </table>
</div>`
  });

  const [d] = await Promise.allSettled([deliver, notify]);
  const ok = d.status === 'fulfilled' && d.value.ok;
  return ok
    ? json({ ok: true })
    : json({ ok: false, error: 'Could not send. Please try again.' }, 502);
}
```

## 3. Reuse your existing helpers

You almost certainly already have equivalents of these. Use yours rather than adding duplicates:

```js
function sendEmail(env, { to, reply_to, subject, html }) {
  return fetch('https://api.resend.com/emails', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${env.RESEND_API_KEY}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      from: `The Sarah Edwin Group <${env.NOTIFY_FROM}>`,
      to, reply_to, subject, html
    })
  });
}

function esc(s) {
  return String(s).replace(/[&<>"']/g, c =>
    ({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[c]));
}
```

## 4. Environment variables

Workers & Pages → your Worker → Settings → Variables and Secrets.

| Variable | Value | Status |
|---|---|---|
| `RESEND_API_KEY` | your key | already set |
| `NOTIFY_TO` | where lead alerts go | check it exists |
| `NOTIFY_FROM` | verified Resend sender | check it exists |
| `EXCERPT_URL` | public URL of the chapter PDF | **add this** |

Save, then redeploy the Worker. Variables don't take effect until you do.

## 5. Host the chapter PDF

Export Chapter 4 as a standalone PDF, put it in the Pages project at `/assets/seg-day-1-readiness.pdf`, and set:

```
EXCERPT_URL = https://www.sarahedwingroup.com/assets/seg-day-1-readiness.pdf
```

The URL is guessable. That's fine — it's a lead magnet, and circulation is the point.

---

## Honeypot

Your existing honeypot check on the `website` field already covers this form. The excerpt page includes the same hidden field, so no change needed — just make sure the check runs before the `form_type` switch rather than inside each branch.
